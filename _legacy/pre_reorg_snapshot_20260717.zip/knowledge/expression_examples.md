# 式サンプル集 (Expression Examples)

migrate_chat_spo案件で実際に使用した式を、汎用化・プレースホルダー化して掲載する。貼り付け可能な式は```で囲んだコードブロック、手順の説明は「擬似コード」と明記する。実在しない関数は使用していない。
関連ルール: [../rules/02_expression_and_type_safety.md](../rules/02_expression_and_type_safety.md) / チェックは[../checklists/expression_type_checklist.md](../checklists/expression_type_checklist.md)を使用。

## 1. 文字列のnull安全化
- 目的: null/未定義の可能性がある文字列を安全にtrimする。
- 入力型: string または null
- 出力型: string
- 式:
```
trim(coalesce(triggerBody()?['Field'], ''))
```
- 使用条件: 対象が文字列であることが前提。`coalesce(trim(x), '')`のようにtrimを先に評価する順序は、xがnullの場合にエラーとなり得るため禁止。
- 注意事項: 配列・オブジェクトには適用しない。

## 2. 配列のnull安全化
- 目的: null/未定義の可能性がある配列をApply to each等へ渡す前に配列として保証する。
- 入力型: array または null
- 出力型: array
- 式:
```
coalesce(body('取得アクション名')?['value'], json('[]'))
```
- 使用条件: Filter array/Selectの出力は元々配列を返すため、その出力に重ねて適用する必要はない。
- 注意事項: 空配列フォールバックに空文字列`''`を使う誤用をしないこと（型不一致）。

## 3. オブジェクトのnull安全化
- 目的: null/未定義の可能性があるオブジェクトのプロパティに安全にアクセスする。
- 入力型: object または null
- 出力型: object
- 式:
```
coalesce(item()?['targetObject'], json('{}'))
```
- 使用条件: プロパティアクセス自体も`?['prop']`の安全参照演算子を併用する。
- 注意事項: オブジェクトのフォールバックに`''`や`json('[]')`を使わない（型を揃える）。

## 4. 投稿者名のフォールバック
- 目的: 投稿者表示名が空の場合に既定文字列へ差し替える。
- 入力型: string または null
- 出力型: string
- 式:
```
if(
  empty(trim(coalesce(items('Process_Each_Parent_Message')?['from']?['user']?['displayName'], ''))),
  '不明',
  trim(coalesce(items('Process_Each_Parent_Message')?['from']?['user']?['displayName'], ''))
)
```
- 使用条件: Apply to eachのループ内でのみ`items('ループ名')`が有効。
- 注意事項: 主催者情報として無条件に流用しない（投稿者と主催者は別概念。主催者は既定値「不明」とし、会議情報から取得できる場合のみ差し替える）。

## 5. 日付の存在確認
- 目的: 日付関数（formatDateTime等）に渡す前に、対象フィールドが存在するか確認する。
- 入力型: string（日時） または null/空文字列
- 出力型: boolean
- 式:
```
not(empty(coalesce(item()?['createdDateTime'], '')))
```
- 使用条件: この式がtrueの場合のみ後続でformatDateTime/convertFromUtcを適用する（Condition分岐と併用）。
- 注意事項: 空文字列を直接日付関数に渡すとエラーになるため、必ず存在確認を先に行う。

## 6. JST変換
- 目的: UTC日時をJST（日本標準時）表示用に変換する。
- 入力型: string（UTC日時）
- 出力型: string（JST日時）
- 式:
```
convertFromUtc(item()?['createdDateTime'], 'Tokyo Standard Time')
```
- 使用条件: 入力が有効なUTC日時文字列であること（事前に「5. 日付の存在確認」を通過していること）。
- 注意事項: 1項目内で複数の日時列を扱う場合、タイムゾーン基準（UTCのまま/JST変換後）を混在させない。同一項目内で基準を統一する。

## 7. 取得期間計算
- 目的: 終了日時から遡って取得対象の開始日時を求める。
- 入力型: string（終了日時UTC）, integer（日数）
- 出力型: string（開始日時UTC）
- 式:
```
addDays(variables('varEndDateUtc'), sub(0, variables('varLookbackDays')))
```
- 使用条件: varEndDateUtc・varLookbackDaysが初期化済みであること。
- 注意事項: 大きな日数（例:730日）を指定する場合、フロー実行時間の上限に注意（[power_automate_tips.md](power_automate_tips.md)参照）。

## 8. HTMLエスケープ
- 目的: プレーンテキストをHTML本文へ安全に埋め込む。
- 入力型: string
- 出力型: string
- 式（Composeを5段に分割する擬似コード）:
```
擬似コード:
Escape_Amp   = replace(元文字列, '&', '&amp;')
Escape_Lt    = replace(outputs('Escape_Amp'), '<', '&lt;')
Escape_Gt    = replace(outputs('Escape_Lt'), '>', '&gt;')
Escape_Quote = replace(outputs('Escape_Gt'), '"', '&quot;')
Escape_Apos  = replace(outputs('Escape_Quote'), "'", '&#39;')
```
- 使用条件: `&`を必ず最初に置換する（後から置換すると、他の置換で生成された`&`まで二重エスケープされる）。改行は`<br>`へ別途置換する。
- 注意事項: この5段はComposeアクションへの分割例（[power_automate_tips.md](power_automate_tips.md)「複雑な式をComposeへ分割する方法」参照）。

## 9. ファイル名サニタイズ
- 目的: ファイル名に使用できない文字を除去し安全なファイル名にする。
- 入力型: string または null
- 出力型: string
- 式（擬似コード。禁止文字を1つずつreplaceで置換）:
```
擬似コード:
名前 = coalesce(元ファイル名, '')
禁止文字 " * : < > ? / \ | をそれぞれ replace(名前, 該当文字, '_') で置換
末尾の空白・ピリオドを除去
長さが上限（例:100文字）を超える場合は拡張子を保持したまま短縮
名前が空の場合は既定名（例:'file'）を使用
```
- 使用条件: 拡張子は保持したまま本体部分のみを短縮する。
- 注意事項: 実際のreplace関数呼び出しは禁止文字の数だけ連鎖させる（実式は本ファイルでは擬似コード化）。

## 10. 添付なし判定
- 目的: 会議（またはメッセージ）に添付ファイルが1件も無いことを判定する。
- 入力型: array または null
- 出力型: boolean
- 式:
```
equals(length(coalesce(item()?['attachments'], json('[]'))), 0)
```
- 使用条件: attachmentsが配列であることを前提とする（事前に配列のnull安全化を適用）。
- 注意事項: 添付が無い場合の表示文言（例:「添付ファイルなし」）はCondition分岐で明示する。

## 11. 保存成功判定
- 目的: 添付ファイルの保存が成功したか（保存後URLが得られているか）を判定する。
- 入力型: string または null
- 出力型: boolean
- 式:
```
greater(length(coalesce(item()?['savedFileUrl'], '')), 0)
```
- 使用条件: status（Saved/Skipped/Failed）ではなく、savedFileUrlの有無で判定する（再利用時のSkippedも正しくリンク表示するため）。
- 注意事項: URLが無い場合はさらにstatusを見て「（保存失敗）」/「（テスト実行のため未保存）」を出し分ける。

## 12. LookbackDaysの既定値
- 目的: トリガー入力の日数指定がnull・未入力・0以下の場合に既定日数へフォールバックする。
- 入力型: integer または null
- 出力型: integer
- 式:
```
if(
  greater(int(coalesce(triggerBody()?['LookbackDays'], 0)), 0),
  int(coalesce(triggerBody()?['LookbackDays'], 7)),
  7
)
```
- 使用条件: 正の整数のみ採用。0以下・未入力は既定値7を採用。
- 注意事項: 上限（例:730日）のバリデーションはこの式自体には含めていない。運用手順書側で注意喚起する。

## 13. Boolean判定
- 目的: トリガー入力のBoolean値をfalseも正しく扱いつつ既定値で補完する。
- 入力型: boolean または null
- 出力型: boolean
- 式:
```
equals(coalesce(triggerBody()?['DryRun'], true), true)
```
- 使用条件: coalesceでnullのみを既定値に置き換え、false自体はfalseのまま評価する。
- 注意事項: `if(triggerBody()?['DryRun'], ...)`のような素通し判定はfalseを未設定と誤解釈しうるため使わない。

## 14. SortKey作成
- 目的: 会議一覧を時系列順にソートするためのキー文字列を作る。
- 入力型: string（日時）, string（ID）
- 出力型: string
- 式:
```
concat(
  formatDateTime(convertFromUtc(item()?['createdDateTime'], 'Tokyo Standard Time'), 'yyyyMMddHHmmss'),
  '_',
  item()?['id']
)
```
- 使用条件: `sort(コレクション, 'sortKey')`は昇順のみ。降順が必要な場合は`reverse()`を併用する。
- 注意事項: 日時部分を先頭に置くことで文字列比較がそのまま時系列比較になる。

## 15. 冪等キー作成
- 目的: 同一の添付ファイルを重複保存しないための一意キーを作る。
- 入力型: string, string, string
- 出力型: string
- 式:
```
concat(item()?['messageId'], '_', coalesce(item()?['replyId'], ''), '_', item()?['attachmentId'])
```
- 使用条件: 台帳（SharePointリスト）を`$filter`でこのキーを検索し、既存Saved項目があれば再処理をスキップする（ForceReprocess=falseの場合）。
- 注意事項: メッセージ本体の添付にはreplyIdが無いため空文字列を許容する。
