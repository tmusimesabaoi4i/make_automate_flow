# エラーカタログ (Error Catalog)

Power Automate開発で実際に発生したエラーの原因・修正方針・再発防止策を記録する。
ここに無いエラーは未確認として扱い、新規発生時は末尾「追記方法」の書式で追記する。

関連ルール: [../rules/03_variables_arrays_and_objects.md](../rules/03_variables_arrays_and_objects.md) / [../checklists/expression_type_checklist.md](../checklists/expression_type_checklist.md)

## WorkflowRunActionInputsInvalidProperty（SetVariable自己参照。保存時）★最重要

### 発生メッセージ
```
フローの保存がコード 'WorkflowRunActionInputsInvalidProperty' およびメッセージ
'The inputs of workflow run action 'Set_MessagesArray' of type 'SetVariable' are not valid.
Self reference is not supported when updating the value of variable 'varMessagesArray'.' で失敗しました。
```

### 発生条件
パッケージ（ZIP）のインポート自体は成功した後、Power Automate画面でフローを保存しようとした時に発生する。「インポート成功＝完成」ではなく、保存操作で初めて検出されるエラーがある点に注意。

### 原因
「変数を設定する」(Set variable / SetVariable) アクションの値式が、更新対象の変数自身を`variables('...')`で参照している（自己参照）。Power Automateはこの自己参照を許可しない。
- 配列蓄積: `union(variables('varX'), 新要素)` をvarX自身にSetVariable
- 文字列連結蓄積: `concat(variables('varX'), 追加文字列)` をvarX自身にSetVariable
- カウンター加算: `add(variables('varX'), 1)` をvarX自身にSetVariable

今回のフローでは自己参照が3件検出された。うち1件はアクション名が`Append_...`だったが、実体（type）はSetVariable+unionであり、**名前ではなくtypeで判定する必要がある**。

### 誤った実装例
```
アクション種類: SetVariable
名前: Set_MessagesArray
値: @union(variables('varMessagesArray'), body('Get_Channel_Messages')?['value'])
```
（varMessagesArrayを更新するのに、値式の中でvariables('varMessagesArray')自身を参照している）

### 修正方針
用途別に自己参照不要な専用アクションへ置き換える。
- (a) 配列蓄積 → Apply to each（配列の各要素をループ）＋「配列変数に追加」(Append to array variable)、値=`item()`。ページ単位の配列をまるごとAppendせず、1要素ずつ追加する。
- (b) 文字列連結蓄積 → 「文字列変数に追加」(Append to string variable)。
- (c) カウンター加算 → 「変数の値を増やす」(Increment variable)。

### 修正例
```
[Apply to each]
名前: Process_Retrieved_Messages
入力: @coalesce(body('Get_Channel_Messages')?['value'], json('[]'))
並列実行: オフ (concurrency.repetitions = 1)
  [中の子アクション]
  アクション種類: AppendToArrayVariable
  名前: Append_Message_To_MessagesArray
  対象変数: varMessagesArray
  値: @item()
```

### ZIP定義上の確認箇所
definition.json内の全アクションを走査し、`"type": "SetVariable"`のアクションについて`inputs.value`の式文字列に、`inputs.name`と同名の`variables('同名')`が含まれていないかを機械チェックする。

### Power Automate画面上の確認箇所
保存時のエラーダイアログのメッセージからアクション名（例:`Set_MessagesArray`）と変数名（例:`varMessagesArray`）を特定し、該当アクションを開いて「値」欄の式を確認する。

### 再発防止チェック
- [ ] 全SetVariableアクションの値式に、更新対象と同名の`variables('...')`参照が無いことを確認した
- [ ] アクション名だけで判断せず実際のtype（SetVariable/AppendToArrayVariable/AppendToStringVariable/IncrementVariable）を確認した
- [ ] 配列・文字列の蓄積は専用のAppend系アクションに置き換えた
- [ ] カウンターはIncrementVariable/DecrementVariableを使用した

### 初出案件
migrate_chat_spo（2026-07-16）

---

## インポート時の式パースエラー「'@' at position ... is not expected」（ネストした@）

### 発生メッセージ
```
電源フローのロジック アプリ フロー テンプレートが無効です。The template language expression
'if(contains(@coalesce(...' is not valid: the string character '@' at position '12' is not expected.
```

### 発生条件
パッケージ（ZIP）をPower Automate画面からインポートする時点（保存より前）で発生。

### 原因
式文字列をプログラム（Pythonなど）で文字列連結生成した際、外側の`@if(...)`の中にネストした関数（`coalesce(...)`等）の前にも誤って`@`を付けてしまった。`@`は式文字列の先頭、または文字列中の`@{...}`補間としてのみ有効であり、関数呼び出しの入れ子部分に単独で付けてはいけない。

### 誤った実装例
```
式（誤り）: @if(contains(@coalesce(triggerBody()?['X'], ''), 'abc'), 'yes', 'no')
```
（外側のifは正しく@始まりだが、内側のcoalesceの前にも@が付いており不正）

### 修正方針
式全体で`@`が使えるのは(1)式文字列の先頭、(2)文字列リテラル内の`@{式}`補間、の2箇所のみと徹底する。ネストした関数呼び出しには`@`を付けない。式を文字列連結で生成する場合は「埋め込み用（@なし）」と「単独式用（@あり）」のテンプレートを明確に分離する。

### 修正例
```
式（正しい）: @if(contains(coalesce(triggerBody()?['X'], ''), 'abc'), 'yes', 'no')
```

### ZIP定義上の確認箇所
definition.json全体をテキストとして走査し、`@`の出現位置が「式文字列の先頭」または「文字列中の`@{`」以外に無いことを機械チェックする。

### Power Automate画面上の確認箇所
インポート時のエラーダイアログに表示される式文字列とエラー位置（position）を確認し、該当アクションの式エディタで入れ子の`@`を除去する。

### 再発防止チェック
- [ ] 式を文字列連結で生成するスクリプトで「埋め込み用」と「単独式用」のテンプレートを分離した
- [ ] 定義全体に対して不正な位置の`@`が0件であることを機械走査で確認した
- [ ] インポート前に生成JSONをパースし、主要な式をサンプリング確認した

### 初出案件
migrate_chat_spo（2026-07-16）

---

## アクション名の全体重複（事前検出。インポート破損の原因になる）

### 発生メッセージ
（実行時のエラーメッセージは未確認。事前の機械走査で検出し実インポート前に修正済み。Power Automateはフロー全体でアクション名の一意性を要求するため、重複が残った場合はインポート破損やインポートエラーの原因になり得る。）

### 発生条件
同一フロー内で同じアクション表示名を2箇所以上に配置した場合。今回は「ループ外の初期化用」アクションと「ループ内の更新用」アクションに同一名（例:`Set_ReplyNextLink`）を付けてしまっていた。

### 原因
同じ役割の説明（「次ページURLを設定する」）から初期化アクションと更新アクションに同じ名前を付けてしまった。Power Automateはフロー全体（Scope/ループをまたいで）でアクション名が一意であることを要求する。

### 誤った実装例
```
[ループ外] アクション名: Set_ReplyNextLink （初回のURLを設定）
[ループ内] アクション名: Set_ReplyNextLink （毎回URLを更新）
```
（同一フロー内に同名アクションが2箇所存在）

### 修正方針
「初期化用」と「ループ内更新用」で名前を分ける。サフィックス`_First`を初期化用に付ける命名規則を統一する。

### 修正例
```
[ループ外] アクション名: Set_ReplyNextLink_First （初回のURLを設定）
[ループ内] アクション名: Set_ReplyNextLink （毎回URLを更新）
```
（同型パターン: Set_NextLink_First / Set_NextLink も同様の命名）

### ZIP定義上の確認箇所
definition.json全体からアクション名（キー）を再帰的に全て収集し、重複が0件であることを機械チェックする。Scope/Foreach/If/Doの子・else子・catchも含めて再帰的に走査する。

### Power Automate画面上の確認箇所
インポートが失敗する、またはフローが壊れた状態で開かれる場合、デザイナー上で同名アクションが複数箇所に表示されていないか確認する。

### 再発防止チェック
- [ ] 全アクション名の重複チェックを機械走査で実施し0件を確認した
- [ ] 「初期化用」と「ループ内更新用」で命名規則（`_First`等）を分けた
- [ ] インポート前の検証スクリプトに重複名検査を含めた

### 初出案件
migrate_chat_spo（2026-07-16）

---

## コネクタ出力の body/ パス欠落（潜在バグ。監査で事前検出）

### 発生メッセージ
```
（保存・インポートではエラーにならない。実行時に値が null になり、後続アクションの失敗や
 「保存失敗」扱いなどの誤動作として現れる。今回は実発生前に設計監査で検出・修正した）
```

### 発生条件
コネクタ（type=OpenApiConnection）アクションの出力フィールドを `outputs('X')?['フィールド名']` で参照した場合。DryRun等でその経路を通らないテストでは発火せず、本番経路で初めて誤動作する。

### 原因
コネクタアクションの `outputs('X')` は封筒構造 `{statusCode, headers, body}` を返す。フィールドは `body` の中にあるため、`outputs('X')?['ItemId']` のような直下参照は**常に null**。
Compose の `outputs('Compose_X')` は封筒を持たないため混同しやすい。

### 誤った実装例
```
@outputs('Create_Attachment_File')?['ItemId']
@outputs('Get_Saved_File_Properties')?['{Link}']
```

### 修正方針
コネクタ出力のフィールドは `body('X')?['フィールド名']`（または `outputs('X')?['body/フィールド名']`）で参照する。

### 修正例
```
@body('Create_Attachment_File')?['ItemId']
@body('Get_Saved_File_Properties')?['{Link}']
```

### ZIP定義上の確認箇所
definition.json内の `outputs('アクション名')?['キー']` をすべて抽出し、参照先アクションが OpenApiConnection の場合にキーが `body` 系（`body` / `body/...`）でなければ誤り、と機械チェックする。同一定義内に `body('X')?['value']` の正しい参照が混在している場合は書き分けの取りこぼしを疑う。

### Power Automate画面上の確認箇所
実行履歴で該当アクションの「出力」を開き、フィールドが `body` の下にネストしていることを確認する。式の評価結果が null になっていないかを後続アクションの「入力」で確認する。

### 再発防止チェック
- [ ] コネクタ出力のフィールド参照がすべて `body('X')?[...]` 形式であることを機械走査した
- [ ] DryRun/テスト経路だけでなく、本番経路（実際に保存・取得する分岐）を最低1件は実走して値を確認した
- [ ] Compose の outputs とコネクタの outputs を混同していない

### 初出案件
migrate_chat_spo（2026-07-16。実働サンプルとの突合監査で実発生前に検出）

---

## OpenApiOperationParameterValidationFailed（PostItem item欠落。保存時）

### 発生メッセージ
```
フローの保存がコード 'OpenApiOperationParameterValidationFailed' およびメッセージ
'Input parameter 'item' validation failed in workflow operation 'Create_Run_Log':
The API operation 'PostItem' is missing required property 'item'.' で失敗しました。
```

### 発生条件
パッケージ（ZIP）のインポート自体は成功した後、Power Automate画面でフローを保存しようとした時に発生する。
保存時のエラーダイアログは**1件ずつ**しか報告しないため、今回は同型の`PostItem`アクションが
`Create_Ledger_Item` / `Create_Ledger_Item_Failed` / `Create_Run_Log` / `Create_Error_Log` の
計4箇所に存在し、1件直して保存し直すたびに次の1件が新たに報告される「もぐら叩き」状態になった。

### 原因
SharePoint「項目の作成」(Create item / operationId=`PostItem`) の本文パラメータ`item`は
`x-ms-dynamic-schema`による動的スキーマで、列単位のフラット化キー（`item/Title`等）は
デザイナーで`dataset`（サイトのアドレス）/`table`（リスト名）を**静的に選択した場合のみ**
解決・生成される。`dataset`/`table`が式（`@variables(...)`等）だと列スキーマを解決できず、
フラット化キーを`item`に束ねられないため、保存時検証で「`item`が欠落している」と判定される。
実働サンプルの`PostItem`はサイト・リストとも静的リテラルの場合にのみ保存実績があった。

### 誤った実装例
```
アクション種類: OpenApiConnection (operationId=PostItem)
名前: Create_Run_Log
dataset: @variables('varSiteUrl')
table: @variables('varRunLogList')
item/Title: @variables('varRunTitle')
item/Result: @variables('varRunResult')
```
（サイト・リストとも式のため列スキーマが解決できず、保存時に`item`欠落エラー）

### 修正方針
`PostItem`を「SharePoint に HTTP 要求を送信」(Send an HTTP request to SharePoint /
operationId=`HttpRequest`) ＋ REST に置き換える。同型のPostItemが複数ある場合は
1件だけ直して満足せず、definition.json全体から`"operationId": "PostItem"`を機械検索し
**残り全件**を洗い出してから修正・保存する。
- 前段にCompose（例:`Compose_Run_Log_Body`）でボディオブジェクトを組み立てる。
- HTTP要求の`parameters/body`には`@string(outputs('Compose_Run_Log_Body'))`を渡す（数値・日時列の型を保持するため文字列化してから送信）。
- `Method`=POST、`Uri`=`_api/web/lists/getbytitle('{listName}')/items`（リスト名部分は式可）。
- `Headers`は`Accept`/`Content-Type`とも`application/json;odata=nometadata`にすれば`__metadata`は不要。
- `dataset`（サイトのアドレス）は静的リテラルで指定する（式にすると同種の問題が再発し得るため）。

### 修正例
```
[Compose]
名前: Compose_Run_Log_Body
入力: {"Title": "@{variables('varRunTitle')}", "Result": "@{variables('varRunResult')}"}

[SharePointにHTTP要求を送信]
名前: Create_Run_Log
Site Address (dataset): {siteUrl}  ※静的リテラル
Method: POST
Uri: _api/web/lists/getbytitle('{listName}')/items
Headers: {"Accept": "application/json;odata=nometadata", "Content-Type": "application/json;odata=nometadata"}
Body: @string(outputs('Compose_Run_Log_Body'))
```

### ZIP定義上の確認箇所
definition.json内で`"operationId": "PostItem"`の存在を機械検査する。`PostItem`が1件でも
残っていれば、`dataset`/`table`が式（`variables(...)`等の式文字列）と併用されていないかを
併せて確認する。式との併用がある場合は保存不可と判定してよい。

### Power Automate画面上の確認箇所
保存時のエラーダイアログのメッセージからアクション名（例:`Create_Run_Log`）を特定し、
該当アクションを開いて「サイトのアドレス」「リスト名」がドロップダウンの静的選択か、
動的コンテンツ（式）になっているかを確認する。

### 再発防止チェック
- [ ] definition.json全体を機械検索し、`"operationId": "PostItem"`が0件、または`dataset`/`table`が
      すべて静的リテラルであることを確認した
- [ ] 保存エラーが1件解消しても即座に完了とせず、同型パターンの残数を機械検索で確認してから再保存した
- [ ] サイト/リストを式にする必要があるアクションはHttpRequest+RESTへ置換した
- [ ] REST置換後のHeadersに`Accept`/`Content-Type`とも`application/json;odata=nometadata`を設定した
- [ ] ハイパーリンク列を使う場合は1行テキスト列への変更を検討した（RESTは`{"Url":...}`形式を要求するため）

### 補足（実行時の残注意・要実環境確認）
- テナント設定によりPOSTで`__metadata`（`ListItemEntityTypeFullName`）の型指定を要求される場合がある。
  その場合はリストの`ListItemEntityTypeFullName`を取得しボディに追加する回避策を検討する。
- 必須の動的ボディを持たない操作（GetItems/GetFileItem/CreateFile/GetFileContentByPath/HttpRequest/HtmlToText）は
  `dataset`/`table`が式でも保存検証を通る（演繹による判断であり直接の実働実績はない）。

### 参照（2026-07-16時点で実在確認）
- https://tomriha.com/http-request-to-create-sp-item-in-dynamic-list-site-with-power-automate/
  （リストを静的選択しない場合は汎用`Item`フィールドのみになる旨の解説）
- https://community.powerplatform.com/ （フォーラム。動的なサイト/リストはCreate itemではなくHTTP requestを推奨する複数スレッドあり）
- https://learn.microsoft.com/en-us/sharepoint/dev/business-apps/power-automate/guidance/working-with-send-sp-http-request
  （`odata=nometadata`ヘッダー、`body('...')['value']`でのアクセス方法を公式解説）
- https://vrdmn.com/2017/04/ （`odata=nometadata`で`__metadata`省略が可能という2017年の実証記事）
- https://techcommunity.microsoft.com/ （PnPブログ等。HttpRequestアクションの構成例）

### 初出案件
migrate_chat_spo（2026-07-16）

---

## GetFileContentByPath の 404 File not found（クロスサイト参照。実行時）

### 発生メッセージ
```
{"status": 404, "message": "File not found\r\nclientRequestId: {guid}"}
```

### 発生条件
パッケージのインポート・保存はいずれも成功した後、**フロー実行時**にSharePoint
「パスによるファイル コンテンツの取得」(Get file content using path /
operationId=`GetFileContentByPath`) アクションで発生する。Teamsチャネルメッセージの
添付（`contentType`=`reference`）の`contentUrl`から`uriPath`でパスを取り出し、
**保存先サイト（添付があるチームサイトとは別サイト）**を`dataset`に指定して取得しようと
していた。

### 原因
実データで以下が確定した。
- (a) Teamsチャネルの添付ファイルは**投稿のあるチームのSharePointサイト**の既定ライブラリ
  （`Shared Documents`/共有ドキュメント）配下に保存される。保存先として別途用意したサイトと
  同一とは限らない。
- (b) Graphが返す`contentUrl`は**生URL（非エンコード）**。日本語ファイル名もそのまま含まれる。
- (c) `GetFileContentByPath`の`path`は**datasetサイトからのサイト相対パス**（サイト接頭辞を
  含まない）。

`dataset`に保存先サイトを指定したまま`contentUrl`の`uriPath`（チームサイト側の絶対パス）を
そのまま`path`に渡したため、`dataset`と`path`が指すサイトが食い違い404になった。

### 誤った実装例
```
[GetFileContentByPath]
dataset: {destinationSiteUrl}  ※保存先サイト。添付があるチームサイトとは別サイト
path: @uriPath(items('Apply_to_each_Attachment')?['contentUrl'])
```
（`contentUrl`のサイトと`dataset`に指定したサイトが異なるため404）

### 修正方針
`contentUrl`を`/Shared Documents/`（共有ドキュメント。既定ライブラリ）の位置で分割し、
前半を`dataset`、後半を`path`に使う。Composeで導出するため設定不要・汎用。
- `Compose_Source_Site` = `@substring(cu, 0, indexOf(cu, '/Shared Documents/'))`
- `Compose_Source_Path` = `@replace(substring(cu, indexOf(cu, '/Shared Documents/')), '%20', ' ')`

予防として、Filter arrayで`contains(contentUrl, '/Shared Documents/')`を条件に加え、
ライブラリ実在ファイルのみを取得対象にする（外部リンク・タブ参照由来の404を事前排除）。
添付有無の明示分岐（If: `length(Filter結果)` > 0）も有効。

### 修正例
```
[Compose] Compose_Source_Site
入力: @substring(items('Apply_to_each_Attachment')?['contentUrl'], 0,
      indexOf(items('Apply_to_each_Attachment')?['contentUrl'], '/Shared Documents/'))

[Compose] Compose_Source_Path
入力: @replace(substring(items('Apply_to_each_Attachment')?['contentUrl'],
      indexOf(items('Apply_to_each_Attachment')?['contentUrl'], '/Shared Documents/')), '%20', ' ')

[GetFileContentByPath]
dataset: @outputs('Compose_Source_Site')
path: @outputs('Compose_Source_Path')
```

### ZIP定義上の確認箇所
`GetFileContentByPath`の`dataset`が`contentUrl`のサイトと一致するかは、definition.json
だけを見る静的検証では判定不能（`contentUrl`は実行時にしか得られない実データのため）。
**実行時検証が必須**と判定してよい。静的走査では`GetFileContentByPath`アクション自体の
存在と、直前にサイト/パスをComposeで分割導出しているかの有無のみ確認できる。

### Power Automate画面上の確認箇所
実行履歴で404になったアクションの「入力」（`dataset`/`path`）と、直前のTeams取得アクション
の`contentUrl`実値を突き合わせ、サイト部分が一致しているかを確認する。

### 再発防止チェック
- [ ] Teams添付のファイル取得は`contentUrl`を`/Shared Documents/`で分割して`dataset`/`path`を導出しているか確認した
- [ ] Filter arrayで`contains(contentUrl, '/Shared Documents/')`により実在ライブラリのファイルのみを対象にした
- [ ] 添付の有無をIfで明示的に分岐した（`length(Filter結果)` > 0）
- [ ] 小規模データで本番経路（DryRun=いいえ）を1件実走し、実データで確認した
- [ ] インポート・保存の成功だけでなく、実行時のクロスサイト参照エラーの有無を確認した

### 初出案件
migrate_chat_spo（2026-07-17・実環境実行で発生）

---

## 追記方法
新しいエラーが発生した場合は、本ファイルに以下の書式で追記する。
```
## エラー名またはコード

### 発生メッセージ
### 発生条件
### 原因
### 誤った実装例
### 修正方針
### 修正例
### ZIP定義上の確認箇所
### Power Automate画面上の確認箇所
### 再発防止チェック
### 初出案件
```
- メッセージは可能な限り全文を引用する（実際のGUID・URL・メールアドレス等の機密性のある実値が含まれる場合はプレースホルダーに置換する）。
- 「初出案件」には案件名と発生日を記載する。
- 調査過程は[../templates/error_investigation_template.md](../templates/error_investigation_template.md)を使って記録し、確定後に本ファイルへ集約する。
