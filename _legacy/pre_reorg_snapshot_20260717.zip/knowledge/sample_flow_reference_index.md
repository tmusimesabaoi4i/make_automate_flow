# サンプルフロー参照インデックス

過去に参照した雛形・実働サンプルの所在と、参考にした点・流用してはいけない点をまとめる。
**「実際のエクスポートだから正しい」とはみなさない。** 実働サンプルにも設計バグが含まれていた（下記参照）。関連ルール: [../rules/07_export_import_package_rules.md](../rules/07_export_import_package_rules.md)

## tmp_20260716051507.zip（雛形サンプル）

- サンプル名: tmp_20260716051507.zip
- 保存場所: migrate_chat_spo案件の受領資料。検証時は変更・上書きせず読み取り専用の参照展開先（例:`sample_extracted_ref/`）へ展開して確認した。
- パッケージ形式: レガシーPower Automateパッケージ（ルートmanifest.json＋`Microsoft.Flow/flows/{guid}/(definition|apisMap|connectionsMap).json`）。ソリューション形式ではない。
- 主なコネクタ: Microsoft Teams（HttpRequestによるGraph呼び出し）／SharePoint
- 参考になる処理: パッケージのフォルダ構成・manifest.jsonの構造・connectionReferencesの形式（Invoker形式＋X-MS-APIM-Tokens参照式の認証）。ZIP直下階層をこの雛形と一致させることでインポート可能な構造を確保した。
- そのまま流用してはいけない処理: 案件固有の実値（Team ID・サイトURL等）は流用しない。雛形自体の設計ロジックの当否は個別確認していない。
- 確認済みエラー: 直接起因のエラーなし（構造参照のみに使用）。
- 利用時の注意: 匿名化（メールアドレス・creator.id・tenantId・接続GUID）を必ず行ってから流用する。
- 関連案件: migrate_chat_spo

## create_meeting_list_sample_20260716105612.zip（実働サンプル）とそのdefinition.json

- サンプル名: create_meeting_list_sample_20260716105612.zip
- 保存場所: 実環境で作成・動作実績のあるエクスポートファイル。読み取り専用で参照し、内部のdefinition.jsonは整形済みJSONとして別途確認した。
- パッケージ形式: レガシーPower Automateパッケージ。connectionReferencesはEmbedded形式＋`authentication="@parameters('$authentication')"`（雛形のInvoker形式とは別の正当な形式）。
- 主なコネクタ: Microsoft Teams（HttpRequest）／SharePoint（PostItem等）／Content Conversion（HtmlToText）
- 参考になる処理:
  - Graph URLの`uriComponent()`エンコード構成（チャネルID・メッセージIDに`:`や`@`を含む場合の実際の動作例）
  - `body('Teams HttpRequest')`がGraph応答JSONそのものである実例（Apply to eachの入力が`body('ParseJson')?['value']`で動作しており、ParseJsonのcontentがGraph応答であることの根拠になる）
  - HtmlToTextのパラメータキーが`Content`であることの実例
  - SharePoint PostItemの内部列名の形式（日本語表示名列が`OData__xHHHH_`形式になる例）
  - connectionReferencesのEmbedded形式の実例
- そのまま流用してはいけない処理:
  - `SetVariable`による`union(createArray(item()), coalesce(...))`の毎回上書き（配列蓄積ではなく上書きになり、複数返信の添付が最後の1件しか残らないバグ）。加えて返信オブジェクト自体が添付配列へ混入していた（後段のFilterで偶然除去されていただけ）。
  - **取得前に既存SharePoint項目を全削除する順序**（Graph取得が失敗・0件でも削除済みでロールバック不能。破壊的処理は新規データ取得の成功後にのみ行う）。
  - ページング処理が無い（1ページ分＝`$top=50`のみ取得。50件超のデータは取得漏れになる）。
  - Parse JSONのスキーマが封筒形（`statusCode`/`headers`/`body`）である一方、実際の参照パスは`?['value']`で不一致（トップレベルの`required`が無いため偶然エラーにならず素通りしていた「デッドスキーマ」）。
  - SharePointへ渡す値式の末尾に`\n`が混入し、列値にそのまま改行が保存されていた。
  - トリガーのスキーマが空、URL・リストGUIDがハードコードされていた。
  - タイトル列はlastModifiedDateTimeのJST変換、投稿日時列はcreatedDateTimeのUTCそのまま、というように同一項目内でタイムゾーン基準が不整合だった。
  - メンション情報を`mentions?[0]?['mentionText']`のように先頭決め打ちで参照していた（複数メンション時の妥当性の検証なし）。
- 確認済みエラー: このサンプル自体のインポート・保存エラーは確認していないが、上記の設計バグ（累積ロジック・タイムゾーン不整合・デッドスキーマ等）を機械解析で発見した。
- 利用時の注意: 「実環境で作成された＝正しい実装」ではない。個々のロジックは必ず機械解析・レビューしてから流用する。
- 関連案件: migrate_chat_spo

---
関連: [connector_action_notes.md](connector_action_notes.md) / [../checklists/design_review_checklist.md](../checklists/design_review_checklist.md)
