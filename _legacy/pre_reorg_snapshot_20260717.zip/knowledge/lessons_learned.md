# 教訓集（migrate_chat_spo 案件 / Teams課内会議アーカイブ）

Teams チャネルの課内会議アーカイブを SharePoint に移送する単一クラウドフローを作る過程で得た教訓を、
「結果」だけでなく「なぜその判断に変えたか」を含めて記録します。ルールの詳細は各ルールファイルへリンクします。

## 表記
- 【事実】= 案件で実証、または公式確認済み。 【推奨】= 事実から導いた指針。 【案件固有】= 今回だけの判断。
- 【要実環境確認】= 実環境で未検証。 公式資料の参照日は 2026-07-16。
- 実値は書かず `{teamId}` `{channelId}` `{siteUrl}` `{listId}` `{destinationPath}` を使う。

## 1. 最初の設計方針
- 【案件固有】Teams チャネルの会議投稿・返信・添付を収集し、整形して SharePoint に保存し、
  処理台帳と実行ログを残す、という一連の自動化を目標に置いた。
- 【案件固有】第1段階の成果物は設計資料のみで、当初は役割別の複数フロー（5フロー統合構成）として設計した。
- 【事実】最終成果物は手動トリガー（インスタントクラウドフロー）1本。取得→整形→保存→台帳→ログを1フローに集約した。

## 2. Azure 不使用方針への変更経緯
- 【案件固有】「Azure・プレミアム・独自コード・汎用HTTP・アプリ登録を使わない」は案件当初からの環境制約
  （一般ユーザー権限のみで完結させる要件）。管理者権限・アプリ登録を前提にできない環境だった。
- 【背景】Teams のメッセージは Microsoft Graph から取得する。素朴には Graph 呼び出しに
  Azure AD アプリ登録＋管理者同意（HTTP with Microsoft Entra ID / 旧 HTTP with Azure AD）が要ると考えがち。
- 【事実】しかし Teams 標準コネクタの「Send a Microsoft Graph HTTP request（operationId=HttpRequest）」は、
  標準接続だけで Graph GET を実行でき、Azure AD アプリ登録も管理者同意も不要と確認できた。
  この確認が「制約下でも要件を満たせる」判断の決め手になった。→ [04](../rules/04_connectors_permissions_and_dlp.md)。

## 3. 複数フロー → 単一フローへの変更理由
- 【背景】第1段階では役割別の5フロー統合構成で設計した（設計資料のみ）。
- 【変更理由1】第2段階の要件が「インポートできる実物のZIPを1つ・フロー1本」だったため。
  複数フロー＋子フローはZIPパッケージ・接続再マッピング・権限管理が複雑になる。
- 【変更理由2】運用が「定期実行」ではなく「システム移行前に過去2年分を一度に取得する一回性の処理」と
  判明したため、フロー間の状態受け渡し（配列・カウンター・実行状況）を作る利点が薄く、
  状態を1フロー内の変数で持てる単一フロー＋Scope整理が最も単純だった。
- 【推奨】分割は実行時間上限超過・共通処理の再利用・権限境界の相違などがあるときに限る。→ [01](../rules/01_flow_architecture_rules.md)。

## 4. サンプルZIP採用理由
- 【事実】レガシーパッケージ（.zip）の内部フォーマット詳細は公式に公開されていない。
- 【変更理由】そこで既存の配布済みパッケージ（雛形）と、実環境で動作実績のある実働サンプルの中身を解析し、
  5ファイル構造・接続参照の形式を雛形に合わせて生成した。ゼロから推測で組むより破損リスクが低い。→ [07](../rules/07_export_import_package_rules.md)。

## 5. SetVariable 自己参照エラー（最重要）
- 【事実】保存時に `WorkflowRunActionInputsInvalidProperty`（Self reference is not supported）が発生。
  「変数の設定（Set variable）」の値式に更新対象の変数自身（`union(自身, …)` 等）を含めていたのが原因。
- 【事実】検出は3件（`Set_MessagesArray` / `Set_RepliesArray` / `Append_Reply_Attachment_Candidates`）。
  3件目は名前が Append でも実体は SetVariable＋union。**名前でなく type を見る**。
- 【変更内容】配列は Append to array variable、文字列は Append to string variable、
  カウンターは Increment variable に置換した。→ [03](../rules/03_variables_arrays_and_objects.md)。

## 6. インポートできても保存できない問題
- 【事実】上記5はインポートでは検出されず、**インポート成功後の保存で初めて失敗**した。
- 【教訓】「インポートできた＝完成」ではない。インポート後は 開く→即保存→フローチェッカー→小規模テスト を必ず行う。→ [07](../rules/07_export_import_package_rules.md)。

## 7. サンプルフローから参考にできた点
- 【事実】Teams「Send a Microsoft Graph HTTP request」で Graph GET が標準接続で動く実装パターン。
- 【事実】チャネルID（`:` `@` を含む）の URL エンコード必須と、メッセージIDの `uriComponent()` 処理。
- 【事実】`body('<Graph HTTP>')` が Graph 応答JSONそのもの（封筒ではない）であること。
- 【事実】HtmlToText のパラメータキーが `Content`、SharePoint PostItem が dataset/table/item 形式であること。
- 【事実】接続参照キーに `-2` 等のサフィックスが付き、`host.connectionName` と一致させる必要があること。→ [05](../rules/05_sharepoint_and_teams_patterns.md)。

## 8. 流用できなかった点（サンプルにも設計バグはある）
- 【事実・アンチパターン】添付蓄積が SetVariable の上書きで、複数返信の添付が最後の1件しか残らない。
- 【事実・アンチパターン】ページング無し（`$top=50` の1ページのみ）で50件超が取得漏れ。→ [05](../rules/05_sharepoint_and_teams_patterns.md)。
- 【事実・アンチパターン】Parse JSON が封筒形スキーマで実参照パスと不一致（required 未評価で偶然通過）。
- 【事実・アンチパターン】取得前に既存項目を全削除（取得失敗時ロールバック不能）、値式末尾の `\n` 混入、
  タイムゾーン基準の不整合。→ 破壊的処理は取得成功後に。[05](../rules/05_sharepoint_and_teams_patterns.md)。

## 9. Teams コネクタの Graph 要求
- 【事実】Teams のメッセージ/返信取得は Graph 経由。URL は `{teamId}/{channelId}/messages` と
  `.../messages/{messageId}/replies`。チャネルIDは `uriComponent()` でエンコード、teamId は GUID で不要。
- 【事実】`$top=50` だけでは完了せず、`@odata.nextLink` を Do until で追跡して全件取得する。→ [05](../rules/05_sharepoint_and_teams_patterns.md)。

## 10. trim・coalesce・配列型の注意
- 【事実】基本形は `trim(coalesce(<文字列 or null>, ''))`。`coalesce(trim(x), '')` は禁止（null で trim 失敗）。
- 【事実】coalesce の候補は同一型（文字列 `''` / 配列 `json('[]')` / オブジェクト `json('{}')`）。
- 【事実】Apply to each の入力は配列保証（`coalesce(x, json('[]'))` か Filter/Select 出力）。
- 【事実】`@` はネスト関数に付けない（インポート式パースエラーの原因）。→ [02](../rules/02_expression_and_type_safety.md)。

## 11. Word 生成制約
- 【事実】標準コネクタだけで真正 .docx は動的生成できない（Word テンプレート機能はプレミアム）。
- 【案件固有】HTMLベースの Word 互換 `.doc` を採用。HTML を `.docx` にリネームするのは破損になるため禁止。
- 【事実】HTMLエスケープは `&` を最初に、改行は `<br>`、改ページは2件目以降のみ。→ [06](../rules/06_word_html_document_generation.md)。

## 12. 7日間から段階検証する方針
- 【変更理由】いきなり全期間（730日）を回すと実行時間上限（目安 約30分）や取得漏れのリスクが高い。
- 【推奨】`7日 → 30日 → 365日 → 730日` と対象期間を段階的に広げ、各段階で件数・失敗・成果物を確認する。
  上限を超えそうなら期間を分割して複数回実行する。→ [08](../rules/08_error_handling_and_idempotency.md)。

## 13. 今後、最初から行うべきこと
- 【推奨】変数更新は最初から専用アクション（Append to array/string、Increment）を使い、SetVariable 自己参照を作らない。
- 【事実→推奨】コネクタ（OpenApiConnection）出力のフィールドは `body('X')?['field']` で参照する。
  `outputs('X')` は封筒 `{statusCode, headers, body}` を返すため `outputs('X')?['field']` は**常に null**
  （正しくは `outputs('X')?['body/field']`）。本案件では設計監査で5箇所の潜在バグとして検出・修正した
  （DryRun既定では発火せず、本番経路でのみ全添付が保存失敗になるところだった）。
  ※Compose の `outputs('Compose_X')` は封筒を持たないためそのままでよい。
- 【推奨】インポート前に機械走査（JSON構文/runAfter整合/重複名/自己参照/重複初期化/接続突合/不正@/operationId実在/匿名化リーク）を回し、0件にする。
- 【推奨】実値はプレースホルダー化し、標準コネクタで完結する設計を優先する（Azure・管理者権限を前提にしない）。
- 【推奨】未確認事項は「要実環境確認」と明記し、公式で確認できないことは断定しない。

## 14. 今後、避けるべきこと
- 【禁止/回避】SetVariable での自己参照（配列 union / 文字列 concat / `add(自身,1)`）。
- 【禁止/回避】ネスト関数への `@` 付与、`coalesce(trim(...), '')`、coalesce 候補の型ずれ。
- 【禁止/回避】HTML の `.docx` リネーム、ページング省略、取得前の破壊的削除、Teams contentUrl の成果物流用。
- 【回避】「今回たまたま動いた」ことの無条件な一般化（例: 未エンコードURLでの動作を前提にしない）。
- 【回避】「インポート成功＝完成」という思い込み。保存・チェッカー・小規模テストまでを完了条件にする。

## 15. 保存時検証は1件ずつしか報告しない（もぐら叩き）＋ Create item の動的サイト/リスト制約
- 【事実】保存時のエラーダイアログは**1件ずつ**しか報告しない。今回は同型の`PostItem`
  （Create item）が4箇所あったが、1件直して保存し直すたびに次の1件が新たに報告される
  「もぐら叩き」状態になった。
- 【教訓】同種エラーが出たら1件の修正で満足せず、definition.json全体を機械検索して
  **同型パターンの残数**を確認してから再保存する。対症療法の繰り返しは手戻りの原因になる。
- 【事実】原因は`PostItem`の必須動的ボディ`item`が、`dataset`（サイト）/`table`（リスト）を
  **静的選択した場合のみ**列スキーマを解決できる制約による。式（変数）のサイト/リストでは
  `item`を構築できず`OpenApiOperationParameterValidationFailed`で保存が失敗する。
- 【推奨】サイト/リストを式にする必要があるなら`PostItem`ではなく
  「SharePoint に HTTP 要求を送信」＋RESTに置換する。→ [05](../rules/05_sharepoint_and_teams_patterns.md)、[エラーカタログ](./error_catalog.md)。

## 16. 静的検証で捕捉できない実行時エラー（クロスサイト参照）
- 【事実】今回の`GetFileContentByPath`の404は、**インポート成功→保存成功→実行時エラー**という
  3段階目で初めて顕在化した。「保存できた＝完成」でもないことが分かった。
- 【事実】原因確定の決め手は実行結果（実データ）の提供だった。Teamsチャネル添付の`contentUrl`が
  投稿のあるチームのサイト（`Shared Documents`配下）を指しており、保存先として別途指定していた
  サイト（`dataset`）と一致していなかった。机上の式検証だけでは気づけなかった。
- 【教訓】Teamsチャネルの添付ファイルは**投稿のあるチームのサイト**に保存され、保存先サイトと
  同一とは限らない。`contentUrl`を`/Shared Documents/`でサイトとパスに分割導出する。
  → [05](../rules/05_sharepoint_and_teams_patterns.md)、[エラーカタログ](./error_catalog.md)。
- 【教訓】ネスト深さが上限（8）ちょうどのフローで分岐を追加する場合、新規Scope追加ではなく
  既存Scopeの型を置き換える方式で深さを増やさずに対応する。→ [01](../rules/01_flow_architecture_rules.md)。

関連: [00 コアルール](../rules/00_power_automate_core_rules.md) / [03 変数・配列](../rules/03_variables_arrays_and_objects.md) / [05 SharePoint/Teams](../rules/05_sharepoint_and_teams_patterns.md) / [07 エクスポート/インポート](../rules/07_export_import_package_rules.md) / [エラーカタログ](./error_catalog.md)
