# SharePoint REST によるリスト自動作成パターン集 (SharePoint REST List Provisioning Patterns)

Power Automateから SharePoint REST（`_api/web/lists`系）を呼び出し、リスト・列・ビューをフロー実行時に自動作成するための再利用可能なパターン集。リスト作成の半冪等化・列作成の冪等化・ビュー再構築・定数保持の4点が要点。

区分: 実働サンプル確認＋本案件で静的検証済み（実環境実行は要確認）。

実値は書かず `{siteUrl}` `{listName}` `{fieldName}` 等のプレースホルダーを使う。日本語名・英語名は併記する。

## 1. リスト作成（作成 / Create list）
```
Method: POST
Uri:    _api/web/lists
Headers: {"Accept": "application/json;odata=verbose", "Content-Type": "application/json;odata=verbose"}
Body:
{"__metadata": {"type": "SP.List"}, "AllowContentTypes": true, "BaseTemplate": 100, "ContentTypesEnabled": true, "Title": "{listName}"}
```
- 【事実】`BaseTemplate:100` はカスタムリスト（汎用リスト）。`odata=verbose` は `__metadata` を含めるため必須。

## 2. 半冪等パターン（作成失敗でも継続）【本案件の改善】
- 【推奨】リスト作成の直後（リストIDを取得するGetByTitleアクション）の `runAfter` を4状態すべてにする。

  ```
  runAfter: { "Create_{listName}List": ["Succeeded", "Skipped", "Failed", "TimedOut"] }
  ```

  リストが既存で作成が失敗しても、後続のGetByTitleで既存リストを取得し処理を継続できる（削除して作り直さない）。
- 【運用注記】2周目以降の実行では、リスト作成アクションが失敗表示のままでもフロー全体は **Succeeded** になる。「作成失敗＝異常」と誤解しないよう運用者へ周知する。

## 3. リストID取得（Get list by title）
```
Method: GET
Uri:    _api/web/lists/GetByTitle('{listName}')?$select=Id,Title&$expand=RootFolder
Headers: {"Accept": "application/json;odata=nometadata"}
```
- IDはComposeで保持: `@trim(string(body('Get_{listName}List')?['Id']))`

## 4. 列作成（createFieldAsXml）
```
Method: POST
Uri:    _api/web/lists/GetByTitle('{listName}')/fields/createFieldAsXml
Headers: {"Accept": "application/json;odata=verbose", "Content-Type": "application/json;odata=verbose"}
Body:
{"parameters": {"__metadata": {"type": "SP.XmlSchemaFieldCreationInformation"}, "Options": 0, "SchemaXml": "<Field .../>"}}
```
- 【事実】`Options:0` では内部名（InternalName）が表示名（DisplayName）から自動生成される。日本語表示名だと内部名がUnicodeエスケープ（`OData__xHHHH_`形式）になり、後続の`$filter`や参照が壊れやすい。実働サンプルは表示名でFilterして実InternalNameをその都度引く回避策を取っていた。
- 【推奨】`DisplayName=Name=ASCII`（半角英数字）にすれば内部名は指定名と一致し安定する。日本語で見せたい場合は別途表示名変更を検討する。
- 型別SchemaXml例（型に無関係な属性は混ぜない）:
  ```
  Text  : <Field Type="Text"  DisplayName="{fieldName}" Name="{fieldName}" Required="FALSE" MaxLength="255" />
  Note  : <Field Type="Note"  DisplayName="{fieldName}" Name="{fieldName}" Required="FALSE" RichText="FALSE" NumLines="6" />
  Number: <Field Type="Number" DisplayName="{fieldName}" Name="{fieldName}" Required="FALSE" />
  ```
  - Note型はMaxLength=255超（URL等）の対策に使う。**OData `$filter` 不可**な点に注意。
  - Number型は`Decimals`未指定で自動判定。

## 5. 列作成の冪等化【本案件の改善・参照フローに無い】
参照フローには存在しない改善。列を作る前に存在確認し、無いときだけ作成する。
1. `Get_{listName}Fields`: `GET .../fields?$select=Title,InternalName,TypeAsString`（`odata=nometadata`）
2. `Filter_{listName}_{fieldName}`（Filter array）: `from = @coalesce(body('Get_{listName}Fields')?['value'], json('[]'))`、`where = @equals(coalesce(item()?['InternalName'], ''), '{fieldName}')`
3. `If_Create_{listName}_{fieldName}`（If）: 条件式 `@equals(length(body('Filter_{listName}_{fieldName}')), 0)`（整数比較。実環境インポート実績のある形）
4. 条件成立時（0件＝未作成）のときだけ createFieldAsXml を実行する。**既存列の削除・再作成はしない。**

## 6. ビュー再構築（既定ビューの列を組み直す）
1. `removeAllViewFields`: `POST .../defaultView/viewfields/removeAllViewFields()`（`odata=nometadata`・ボディなし）
2. 列一覧を再取得（`Get_{listName}FinalFields`、手順3と同じGET）
3. `AddViewField`: 列ごとに1回

  ```
  Method: POST
  Uri:    _api/web/lists/GetByTitle('{listName}')/defaultView/viewfields/AddViewField('{internalName}')
  Headers: {"Accept":"application/json;odata=verbose","Content-Type":"application/json;odata=verbose","IF-MATCH":"*","X-HTTP-Method":"MERGE"}
  Body:   {"__metadata": {"type": "SP.View"}, "SetAsDefaultView": true}
  ```

- 【事実】タイトル列の再追加は `Title` ではなく **`LinkTitle`**（リンク・メニュー付き）で行う。
- システム列（`Author` / `Editor` / `Created` / `Modified`）も同じ`AddViewField`で追加できる。
- 手順4で内部名が化ける場合は、Filter＋Compose（`ComposeInternalName_...`）で表示名から実InternalNameを引いてから渡す。

## 7. Title列のRequired解除【必要な場合のみ】
```
Method: POST
Uri:    _api/web/lists/GetByTitle('{listName}')/fields/getbyinternalnameortitle('Title')
Headers: {"Accept":"application/json;odata=nometadata","Content-Type":"application/json;odata=nometadata","IF-MATCH":"*","X-HTTP-Method":"MERGE"}
Body:   {"Required": false}
```
利用側が項目作成時に常にTitleへ書き込むフロー設計なら不要。

## 8. EnableAttachments（添付ファイルの許可）【必要な場合のみ】
```
Method: POST
Uri:    _api/web/lists/GetByTitle('{listName}')
Headers: {"Accept":"application/json;odata=verbose","Content-Type":"application/json;odata=verbose","IF-MATCH":"*","X-HTTP-Method":"MERGE"}
Body:   {"__metadata": {"type": "SP.List"}, "EnableAttachments": true}
```
利用実績が無ければ実施しない。

## 9. 定数はComposeで保持する（SetVariableにしない）
- 【推奨】リスト名・リストIDなど使い回す定数は「変数を設定する」(SetVariable) ではなく **Compose** で保持する。
  ```
  Compose_{listName}ListTitle: 入力 = "{listName}"
  ```
  以降は `outputs('Compose_{listName}ListTitle')` で参照する。SetVariableは更新式が自身の変数を参照すると保存エラーになる（[03 変数・配列](../rules/03_variables_arrays_and_objects.md)、[エラーカタログ](error_catalog.md)）。Composeで保持すればこの自己参照事故を**構造的に**排除できる。

## パッケージ化する場合の注意
本パターンをレガシーZIPで配布する場合のGUID一致要件（3点一致）は[../rules/07_export_import_package_rules.md](../rules/07_export_import_package_rules.md)を参照。

---
関連: [../rules/05_sharepoint_and_teams_patterns.md](../rules/05_sharepoint_and_teams_patterns.md) / [../rules/07_export_import_package_rules.md](../rules/07_export_import_package_rules.md) / [error_catalog.md](error_catalog.md)
