# コネクタ・アクション仕様メモ

今回確認したコネクタ・アクションの入力パラメータと確認根拠をまとめる。実環境での最終確認が必要な項目には「要実環境確認」と明記する。
確認日: 2026-07-16。関連ルール: [../rules/05_sharepoint_and_teams_patterns.md](../rules/05_sharepoint_and_teams_patterns.md)

## Microsoft Teams（shared_teams）

### Send a Microsoft Graph HTTP request（operationId: HttpRequest）
- 標準（非プレミアム）コネクタ・アクション。Azure ADアプリ登録・管理者同意は不要。
- 主要パラメータ: `Uri`（呼び出すGraph APIのURL）/ `Method`（GET等）/ `ContentType`。
- 用途例: `GET https://graph.microsoft.com/v1.0/teams/{teamId}/channels/{channelId}/messages?$top=50`、`.../messages/{messageId}/replies?$top=50`。
- 応答: `body('アクション名')`はGraph応答JSONそのもの（`statusCode`/`headers`/`body`の封筒形ではない）。
- 確認日: 2026-07-16 / 根拠: 雛形サンプル（tmp_20260716051507.zip）・実働サンプル（create_meeting_list_sample_20260716105612.zip）の両方で実際に使用され動作実績あり。
- 要実環境確認: `{channelId}`のような`:`や`@`を含む識別子は`uriComponent()`でのエンコードが必要（実働サンプルで確認済み）。`@odata.nextLink`によるページングの絶対URL受理可否は未確認。

### Get messages in a channel / List replies of a channel message（参考・未使用）
- operationId: `GetMessagesFromChannel` / `ListRepliesToMessage`。標準コネクタ。
- `ListRepliesToMessage`の`$top`既定20・最大50。
- 今回のフローでは簡易代替として整理したのみで未使用（HttpRequest方式を採用）。
- 確認日: 2026-07-16 / 根拠: 公式資料（Teamsコネクタリファレンス）。

## SharePoint（shared_sharepointonline）

### GetItems（Get items）
- 主要パラメータ: `dataset`（サイトURL、例:`{siteUrl}`）/ `table`（リスト/ライブラリ、例:`{listId}`）/ `$filter` / `$orderby` / `$top`。
- 用途: 処理台帳（冪等性確認用リスト）の既存項目検索。
- 確認日: 2026-07-16 / 根拠: 公式資料＋雛形サンプル。

### PostItem（Create item）
- 主要パラメータ: `dataset` / `table` / `item`（列内部名ベースのオブジェクト）。
- 要実環境確認: 日本語表示名の列は内部名が`OData__xHHHH_`形式（例:`item/OData__x30d5__x30a1__x30a4__x30eb_`）になる場合がある。列内部名はインポート後に実際のリストへ再選択して確認する。
- 確認日: 2026-07-16 / 根拠: 実働サンプルの機械解析＋公式資料。

### CreateFile（Create file）
- 主要パラメータ: `dataset` / `folderPath`（例:`{destinationPath}`）/ `name` / `body`。
- 用途: 添付ファイル・総括文書ファイルの保存。
- 確認日: 2026-07-16 / 根拠: 公式資料＋雛形サンプル。

### GetFileItem（Get file properties）
- 主要パラメータ: `dataset` / `table` / `id`。
- 要実環境確認: 保存後URL参照式`outputs(...)?['{Link}']`はコミュニティ情報のみで、公式資料に直接の記載なし。代替として`{FullPath}`+サイトURLの組み立ても検討する。
- 確認日: 2026-07-16 / 根拠: 公式資料（Link/FullPath/Pathの存在は確認済み）＋コミュニティ情報（Link参照式は未確認）。

### GetFileContentByPath（Get file content using path）
- 主要パラメータ: `dataset` / `path`。
- 要実環境確認: 添付contentUrlの実際のパス解析可否（カード形式・共有リンク種別により形式が異なりうる）。
- 確認日: 2026-07-16 / 根拠: 公式資料。

## Content Conversion（shared_conversionservice）

### HtmlToText（Html to text）
- 主要パラメータ: `Content`（キー名は`"html"`ではなく`Content`である点に注意。公式資料で確認済み）。
- 用途: HTML形式の投稿本文をプレーンテキスト化。
- 要実環境確認: 接続要否・DLP（データ損失防止）ポリシーとの適合。
- 確認日: 2026-07-16 / 根拠: 公式資料（[../migrate_chat_spo/doc/official_reference_findings.md](../migrate_chat_spo/doc/official_reference_findings.md)）。

---
本メモは[expression_examples.md](expression_examples.md)・[sample_flow_reference_index.md](sample_flow_reference_index.md)と合わせて参照する。実装前に必ず[../checklists/design_review_checklist.md](../checklists/design_review_checklist.md)と照合すること。
