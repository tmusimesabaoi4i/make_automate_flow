# インポート・保存検証チェックリスト

ZIPパッケージの作成後・インポート後に機械的/操作的に確認する項目。
詳細は[../templates/package_validation_report_template.txt](../templates/package_validation_report_template.txt)を参照。関連ルール: [../rules/07_export_import_package_rules.md](../rules/07_export_import_package_rules.md)

## パッケージ作成後（機械検証）
- [ ] ZIPを再展開できることを確認した
- [ ] パッケージ内の全JSONファイルがパース可能であることを確認した
- [ ] （レガシー形式以外を扱う場合のみ）XMLファイルがパース可能であることを確認した。レガシーパッケージはXMLを含まないため該当なし
- [ ] connectionReferencesのキーと、apisMap.json/connectionsMap.json/manifest.jsonのリソースGUIDが一致していることを確認した
- [ ] 全アクションのrunAfter参照先が、同一コンテナ内の兄弟アクションとして実在することを確認した
- [ ] パッケージ内のフロー数が想定通り（子フロー・複数親フローの有無）であることを確認した
- [ ] 全アクション名（表示名）がフロー全体で重複していないことを確認した
- [ ] 実値ID・URL・メールアドレス・接続GUID等の機密情報が混入していないことを確認した（匿名化漏れがない）

## インポート後（Power Automate画面上の操作）
- [ ] インポートを実行し、エラーが出ないことを確認した
- [ ] フローを開き、すべてのコネクタの接続を実環境の接続に再選択した
- [ ] SharePoint等のサイト・リスト・ライブラリを実物に再選択した
- [ ] 再選択後、そのまま一度保存し、保存エラーが出ないことを確認した
- [ ] フローチェッカーを実行し、警告・エラーが0件であることを確認した
- [ ] 小期間（1件または1日分程度）でテスト実行し、期待通りの結果になることを確認した

関連: [../knowledge/error_catalog.md](../knowledge/error_catalog.md) / [release_checklist.md](release_checklist.md)
