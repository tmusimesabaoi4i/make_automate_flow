# Power Automate開発ナレッジ

Power Automateクラウドフロー開発の共通ルール・知見・チェックリスト・テンプレートの知識ベース。
`migrate_chat_spo` 案件（Teams課内会議アーカイブ、2026-07）の実経験（インポートエラー・保存エラー・実働サンプル解析）から抽出した再利用可能な知識を集約する。

## 1. 目的

- 案件で発生したエラーと修正方法を、次の案件で再発させないための共通ルール化
- フロー設計・式の記述・エクスポートZIP作成・インポート検証の標準手順の提供
- 新規案件を最短で正しく始めるためのテンプレートとチェックリストの提供

## 2. ディレクトリ構成

```text
make_automate_flow/
├── README.md                 ← 本ファイル（入口）
├── rules/                    ← 共通ルール（00が最重要・ハブ）
├── knowledge/                ← エラーカタログ・Tips・式例・教訓・サンプル索引
├── checklists/               ← 設計・式型・インポート・リリースの検査表
├── templates/                ← 新規案件用テンプレート
└── migrate_chat_spo/         ← 案件固有資料（Teams課内会議アーカイブ）
```

構成はユーザー指示（2026-07-16）の標準構成をそのまま採用した（既存の共通資料が存在しなかったため調整不要）。
`knowledge/`配下のパターン集の一つ、SharePoint REST によるリスト自動作成は [knowledge/sharepoint_rest_list_provisioning.md](knowledge/sharepoint_rest_list_provisioning.md) を参照。

## 3. 新しいPower Automate案件を始めるときの手順

1. [rules/00_power_automate_core_rules.md](rules/00_power_automate_core_rules.md) を読む（最重要ルールの要約とリンク集）
2. [templates/flow_design_template.md](templates/flow_design_template.md) をコピーして設計書を起こす
3. 設計時に [checklists/design_review_checklist.md](checklists/design_review_checklist.md) で自己レビュー
4. 参考にするサンプルがあれば [knowledge/sample_flow_reference_index.md](knowledge/sample_flow_reference_index.md) で注意点を確認
5. 式を書く際は [knowledge/expression_examples.md](knowledge/expression_examples.md) と [checklists/expression_type_checklist.md](checklists/expression_type_checklist.md) を参照
6. ZIP生成・インポート時は [rules/07_export_import_package_rules.md](rules/07_export_import_package_rules.md) と [checklists/import_save_validation_checklist.md](checklists/import_save_validation_checklist.md) に従う
7. リリース前に [checklists/release_checklist.md](checklists/release_checklist.md) を通す
8. 完了後、[この更新手順](#10-知識を更新する方法) に従って知識を還元する

## 4. 最初に読むルール

| 優先 | ファイル | 内容 |
|---|---|---|
| ★ | [rules/00_power_automate_core_rules.md](rules/00_power_automate_core_rules.md) | 最重要ルール集約（自己参照禁止・型規律・保存テスト） |
| ★ | [rules/03_variables_arrays_and_objects.md](rules/03_variables_arrays_and_objects.md) | SetVariable自己参照の全面禁止と型別更新方式 |
| ★ | [rules/02_expression_and_type_safety.md](rules/02_expression_and_type_safety.md) | @の規則・trim/coalesce・null安全 |
| 　 | [rules/01_flow_architecture_rules.md](rules/01_flow_architecture_rules.md) | Scope構成・命名・ネスト・並列制御 |
| 　 | [rules/07_export_import_package_rules.md](rules/07_export_import_package_rules.md) | ZIP形式・匿名化・インポート後保存テスト |

その他: [04 コネクタ/DLP](rules/04_connectors_permissions_and_dlp.md)・[05 SharePoint/Teams](rules/05_sharepoint_and_teams_patterns.md)・[06 Word/HTML生成](rules/06_word_html_document_generation.md)・[08 エラー処理/冪等性](rules/08_error_handling_and_idempotency.md)

## 5. フロー設計時の確認事項

- [checklists/design_review_checklist.md](checklists/design_review_checklist.md)（単一/複数フロー判断・標準コネクタ・冪等性・制限）
- [checklists/expression_type_checklist.md](checklists/expression_type_checklist.md)（trim/coalesce/自己参照/null/@規則）
- 要点: **SetVariableで更新対象変数自身を参照しない**。配列=「配列変数に追加」、文字列=「文字列変数に追加」、
  カウンター=「変数を増分する」。コネクタ出力のフィールドは `body('X')?['field']` で参照する
  （`outputs('X')?['field']` は封筒構造のため常に null）。

## 6. ZIP生成・インポート時の確認事項

- [checklists/import_save_validation_checklist.md](checklists/import_save_validation_checklist.md)
- 要点: **インポート成功≠完成**。インポート後に必ず (1)フローを開く → (2)すぐに保存 → (3)フローチェッカー →
  (4)小期間（1〜7日・DryRun）でテスト。保存エラーの多く（自己参照等）はインポートでは検出されない。
- 検証レポートは [templates/package_validation_report_template.txt](templates/package_validation_report_template.txt) の書式で作成する。

## 7. エラー発生時の参照先

1. [knowledge/error_catalog.md](knowledge/error_catalog.md) で既知エラーか確認（発生メッセージで検索）
2. 未知のエラーは [templates/error_investigation_template.md](templates/error_investigation_template.md) の手順で調査
3. 解決後、error_catalog.md へ追記（書式はファイル内「追記方法」参照）

代表的な既知エラー:
- `WorkflowRunActionInputsInvalidProperty` / Self reference is not supported → SetVariable自己参照（保存時）
- `the string character '@' at position ... is not expected` → 式内のネストした@（インポート時）
- `OpenApiOperationParameterValidationFailed` / missing required property 'item' → 動的サイト/リスト×Create item（保存時）
- `404 File not found` / GetFileContentByPath → クロスサイト参照（Teams添付と保存先サイトの不一致。実行時）

## 8. テンプレートの使用方法

| テンプレート | 用途 |
|---|---|
| [flow_design_template.md](templates/flow_design_template.md) | 案件開始時の設計書の雛形 |
| [flow_action_definition_template.txt](templates/flow_action_definition_template.txt) | アクション単位の定義書式（設計TXT用） |
| [package_validation_report_template.txt](templates/package_validation_report_template.txt) | ZIP検証レポートの書式（§10集計含む） |
| [error_investigation_template.md](templates/error_investigation_template.md) | エラー調査の記録書式 |
| [lessons_learned_template.md](templates/lessons_learned_template.md) | 案件完了時の振り返り書式 |

コピーして案件ディレクトリ配下で使用する（テンプレート自体は書き換えない）。

## 9. 案件固有資料との切り分け

- **共通知識（本ディレクトリ直下）**: 複数案件で再利用できる一般ルール・パターン・教訓。
  実値（Team ID・Channel ID・サイトURL・リストGUID・接続名・個人メール）は書かず、
  プレースホルダー `{teamId}` `{channelId}` `{siteUrl}` `{listId}` `{destinationPath}` を使う。
  認証情報・アクセストークン・接続固有IDは保存しない。
- **案件固有資料（`migrate_chat_spo/` 等の案件ディレクトリ）**: 特定のID・URL・列構成・判定条件・期間などの実値と、
  その案件だけで通用する設計判断。案件資料だけでも構築できる完結性を保つ（共通ルールの詳細はリンク参照）。

## 10. 知識を更新する方法

案件を完了または大きく修正したら、次の順で知識を還元する（監修: Fable）:

1. 発生した新しいエラーを抽出 → [knowledge/error_catalog.md](knowledge/error_catalog.md) へ所定書式で追記
2. 一般化できる教訓を抽出（案件固有事項と分離）→ [knowledge/lessons_learned.md](knowledge/lessons_learned.md) へ追記
3. 再利用可能な新しい式 → [knowledge/expression_examples.md](knowledge/expression_examples.md) へ追加
4. 新しいサンプルZIP → [knowledge/sample_flow_reference_index.md](knowledge/sample_flow_reference_index.md) へ登録
5. チェックリストの不足 → 該当チェックリストへ追加
6. 既存ルールと矛盾しないか確認（矛盾する場合は履歴を残して現行ルールを明確化）
7. 本READMEのリンク・構成を更新

肥大化させない: 同じ内容は統合し、詳細は1箇所に書いて他はリンクにする。
「今回たまたま動いた」だけの方法を根拠なく一般ルール化しない。公式資料で確認できない内容は「要実環境確認」と明記する。
