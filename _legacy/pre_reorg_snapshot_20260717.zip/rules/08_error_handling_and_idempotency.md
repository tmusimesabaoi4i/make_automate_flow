# エラー処理と冪等性

1件の失敗で全体を止めない設計、処理状況（Status）の記録、再実行しても壊れない冪等（べきとう）キー設計、段階的な検証方法を扱います。Scope の構造的な組み方は [01](./01_flow_architecture_rules.md)、変数更新は [03](./03_variables_arrays_and_objects.md) を参照。

## Scope 分離で危険操作を隔離【推奨】
- 【推奨】外部呼び出し・ファイル作成などの危険操作は Scope（スコープ）に隔離する。
  その Scope の失敗（`Failed`/`TimedOut`）を**後続ハンドラで受けて処理を継続**する。
  runAfter の設定方法は [01 フロー構成ルール](./01_flow_architecture_rules.md)。
- 【案件固有】今回は添付保存を `Scope_Save_File`（元ファイル取得→作成→プロパティ取得）に隔離し、
  失敗時ハンドラで台帳に Failed を記録して次の添付へ進むようにした。

## 1件失敗で全体を止めない【事実・案件固有】
- 【事実・アンチパターン】当初、添付1件の保存失敗が会議処理全体を止め、しかも台帳に Failed が残らなかった。
- 【推奨】ループ内の1件の失敗はその件だけ Failed として記録し、ループ全体は継続させる。
  失敗件数（例 `varFailedCount`）を集計し、実行ログに残す。

## Status を記録する【推奨】
- 【推奨】各項目の結果を明示的な Status で残す。今回の区分:
  - `Saved`（新規保存に成功）
  - `Skipped`（再利用: 既存の保存済みURLあり／DryRun: URL無しで未保存）
  - `Failed`（保存失敗: URL無し、エラーメッセージ付き）
- 【事実・案件固有】成果物リンクの表示可否は**「保存後URLが非空か」**で判定する（Status名だけで判定しない）。
  URLがあれば Saved でも再利用 Skipped でもリンク表示、URL無しは失敗/未保存として区別する。

## 冪等キー設計【事実 + 要実環境確認】
- 【事実】再実行時の二重処理を防ぐため、処理単位ごとに一意な**冪等キー**を作る。今回の形式:

  ```
  {messageId}(_{replyId})_{attachmentId}
  ```

  （返信の添付なら `_{replyId}` を含め、親投稿の添付なら省く）
- 【推奨】処理前に**台帳リスト**を `$filter` で検索し、同じ冪等キーで Status=Saved が既にあれば再利用（Skipped）する。
  台帳の列例: 冪等キー / RunId / MessageId / ReplyId / AttachmentId / 元ファイル名 / 保存名 / 保存URL / Status / エラー / 処理日時。
- 【要実環境確認】台帳の `$filter` 検索は列内部名・エスケープに依存する（[05](./05_sharepoint_and_teams_patterns.md)）。実環境で確認する。

## ForceReprocess / DryRun パターン【案件固有】
- 【案件固有】運用の安全弁として2つのトリガー入力を用意した。
  - `DryRun`（テスト実行, 既定 true）: true のとき破壊的処理（ファイル作成・総括ファイル作成）を行わない。
    今回は DryRun=true でも総括ファイルを作ってしまうバグを、DryRun 分岐で作成しないよう修正した。
  - `ForceReprocess`（既定 false）: true のとき台帳の Saved を無視して再処理する。
    通常は false で処理済みをスキップし、再取得したいときだけ true にする。
- 【推奨】Boolean 入力は既定値付きで厳密判定する（false/0 を未設定扱いしない。[02](./02_expression_and_type_safety.md)）。

## 実行ログ【推奨】
- 【推奨】実行ごとに1件のログ（RunId / フロー名 / 件数 / 保存数 / スキップ数 / 失敗数 / 成果物URL / Status / 発生日時）を残す。
  失敗集計と成果物リンクをここに集約し、後から実行を追跡できるようにする。

## 段階テスト【推奨・案件固有】
- 【推奨】いきなり全期間を処理せず、対象期間を段階的に広げて検証する。今回の段階:

  ```
  7日 → 30日 → 365日 → 730日
  ```

- 【事実】フロー実行には時間上限（目安 約30分）や Do until の回数/タイムアウト上限がある。
  大量データで超えそうなら**期間を分割**して複数回実行する。
- 【推奨】各段階で件数・失敗の有無・成果物を確認してから次の段階へ進む。

関連: [00 コアルール](./00_power_automate_core_rules.md) / [01 フロー構成](./01_flow_architecture_rules.md) / [05 SharePoint/Teams](./05_sharepoint_and_teams_patterns.md) / [教訓集](../knowledge/lessons_learned.md) / [エラーカタログ](../knowledge/error_catalog.md)
