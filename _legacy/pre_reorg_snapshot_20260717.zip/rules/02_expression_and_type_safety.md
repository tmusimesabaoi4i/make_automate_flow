# 式と型の安全性（@規則・trim/coalesce・型規律）

式（ワークフロー定義言語 / Workflow Definition Language）の書き方と型の扱いのルールです。今回のインポートエラーの直接原因である `@` の付け方、null/空文字/空配列の区別、日付・インデックス操作の安全策を扱います。変数更新の詳細は [03](./03_variables_arrays_and_objects.md) を参照。

## `@` の規則（今回のインポートエラーの原因）
- 【事実】`@` は式文字列の**先頭**、または `@{…}` 補間の**中**でのみ有効。
- 【事実】ネストした内側の関数に `@` を付けるとインポート時に式パースエラーになる。
  今回 `if(contains(@coalesce(...` のように内側 `coalesce` に `@` を付けてしまい、
  「the string character '@' at position '12' is not expected」で失敗した。
- 【推奨】正しい形。外側だけ `@` を付け、内側の関数には付けない。

  ```
  @if(contains(coalesce(triggerBody()?['X'], ''), 'foo'), 'A', 'B')
  ```

- 【推奨】式を文字列連結（スクリプト等）で生成する場合は、「補間用（`@`なし）」と
  「単独式用（`@`あり、先頭1個だけ）」を明確に分離し、生成後に不正な `@` が0件であることを機械走査する。

## trim / coalesce の型規律
- 【事実/推奨】基本形は次のとおり。coalesce を**外側**、trim を内側に置く。

  ```
  trim(coalesce(<文字列またはnull>, ''))
  ```

- 【事実】`coalesce(trim(x), '')` は禁止。trim が先に評価され、x が null だと trim が失敗し得る。
- 【事実】`coalesce` の候補は**同一型**でそろえる。文字列は `''`、配列は `json('[]')`、オブジェクトは `json('{}')`。
  型の違う既定値（例: 文字列に `json('[]')`）を混ぜない。

## null・空文字・空配列は別物
- 【推奨】`null` ≠ `''`（空文字）≠ `[]`（空配列）として扱う。存在チェックには目的に合った既定値を与える。
- 【事実/推奨】Boolean の `false` / 数値の `0` を「未設定」と誤判定しない。
  - Boolean 判定は既定値付きで厳密に比較する。

    ```
    equals(coalesce(triggerBody()?['Flag'], false), true)
    ```

  - 数値入力の安全化（既定7、0以下は7に丸める例）。

    ```
    if(greater(int(coalesce(triggerBody()?['LookbackDays'], 0)), 0), int(coalesce(triggerBody()?['LookbackDays'], 7)), 7)
    ```

## 日付関数へ空文字を渡さない
- 【推奨】`formatDateTime` / `convertFromUtc` / `addDays` 等の日付関数へ空文字や null を渡すと実行時エラーになる。
  日付が必ず入る値（トリガー時刻・API応答の日時フィールド）を使い、無い場合は分岐で回避する。
- 【事実】今回は `formatDateTime(convertFromUtc(<...createdDateTime>, 'Tokyo Standard Time'), 'yyyy-MM-dd')`
  のように、必ず値が入る Graph 応答の日時を使っている。

## 計算インデックスの角括弧アクセスを避ける
- 【事実/推奨】`json('[...]')[<計算式>]` のような**計算インデックスの角括弧参照**は式エディタで不安定になり得る。
  関数形で代替する。曜日を出す例（`dayOfWeek` は 0=日曜）。

  ```
  substring('日月火水木金土', dayOfWeek(item()?['meetingDate']), 1)
  ```

- 【注意】上記は「今回この形で堅く動いた」ものを一般化した推奨であり、
  角括弧が常に壊れるという意味ではない。堅い関数形を優先する、という指針。

## 複雑な式は Compose（作成）で分割
- 【推奨】長い・入れ子が深い式は、途中結果を「作成（Compose）」に切り出して段階化する。
  デバッグ時に中間値を確認でき、`@` の付け間違いも減る。今回も有効日数の算出を Compose に分けた。

## Parse JSON（JSONの解析）の注意
- 【推奨】スキーマを作る前に**実レスポンスの形を先に確認する**（実行履歴のサンプルペイロードから
  「スキーマの生成」を使う）。HTTPやコネクタのラッパー（封筒）構造の有無を確認し、
  参照パスが `body/value` か `value` かを**推測で決めない**。
- 【事実・アンチパターン】実働サンプルには、実データがフラット（`{value:[...]}`）なのにスキーマが
  封筒形（`{statusCode, headers, body}`）という不一致があった。トップレベルに `required` が無く、
  `properties` は「キーが存在する場合のみ」検証されるため、入れ子の `required` が一度も評価されない
  「デッドスキーマ」となり偶然通過していた。スキーマと参照パスは必ず一致させる。
- 【推奨】null や欠落し得るプロパティを `required` へ過剰指定しない。スキーマは必要最小限にする。
  式参照だけで足りる場合は Parse JSON 自体を省略してよい（`body('X')?['value']` の直接参照で動作する）。

## 実在確認済みの関数のみ使う
- 【事実】今回使用し公式資料で実在確認した関数: `sort`（昇順のみ。降順は `reverse` 併用）,
  `reverse`, `coalesce`, `trim`, `empty`, `addDays`, `formatDateTime`, `convertFromUtc`, `replace`, `union`, `int`, `if`, `contains`, `substring`, `uriComponent`, `concat`。
  `union` は重複を排除する仕様（配列連結の副作用に注意）→ [03](./03_variables_arrays_and_objects.md)。
- 【推奨】実在しない関数・記憶頼りの関数名を書かない。迷ったら公式の関数リファレンスで確認する
  （learn.microsoft.com のワークフロー定義言語 関数リファレンス。参照日 2026-07-16）。

関連: [00 コアルール](./00_power_automate_core_rules.md) / [03 変数・配列](./03_variables_arrays_and_objects.md) / [06 Word/HTML生成](./06_word_html_document_generation.md) / [エラーカタログ](../knowledge/error_catalog.md)
